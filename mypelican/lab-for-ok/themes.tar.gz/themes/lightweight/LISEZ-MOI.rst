Thème «Lightweight» pour pelican
################################

Description
===========

:Créé le: 14 février 2011
:Technologies utilisées: xHTML5, CSS 1-3, polices TTF
:Couleurs utilisées: Tons froids (gris/bleu)
:Design extensif: Oui
:Testé sous: Mozilla Firefox 4.0b10, Chromium 9.0.597.83, ELinks 0.12pre5
:Langue: Français
:Détails: Voire capture d'écran et source



