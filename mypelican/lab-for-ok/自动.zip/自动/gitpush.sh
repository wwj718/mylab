cd output
git rm .
git add .
git commit -m 'wwj'
git push origin master
cp -r .git ../../ok/
