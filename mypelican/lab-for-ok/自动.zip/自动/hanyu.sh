cd output/tag
mv liu-yu.html 刘瑜.html
mv ri-ji.html 日记.html
mv shi-ci.html 诗词.html

cd ../category
mv du-shu.html 读书.html
mv shi-ci.html 诗词.html
mv sui-bi.html 随笔.html
