cp -r ./ok/.git/ ./lab-for-ok/output/


