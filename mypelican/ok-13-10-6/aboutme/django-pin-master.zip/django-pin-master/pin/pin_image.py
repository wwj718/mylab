import PIL
from PIL import Image

def resize(image, image_out, basewidth=192):

    basewidth = basewidth
    img = Image.open(image)
    wpercent = (basewidth/float(img.size[0]))
    hsize = int((float(img.size[1])*float(wpercent)))
    img = img.resize((basewidth,hsize), PIL.Image.ANTIALIAS)
    img.save(image_out , quality=90)